.. warning::

   Note that the :term:`cchardet` project is known not to support
   Python 3.10 or higher. See :issue:`6819` and
   :gh:`PyYoshi/cChardet/issues/77` for more details.
